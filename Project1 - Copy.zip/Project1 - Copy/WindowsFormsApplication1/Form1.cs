﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Emgu;
using Emgu.CV;
using Emgu.CV.Structure;
using System.Diagnostics;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void ImageOps(Image<Bgr, Byte> img1, Image<Bgr, Byte> img2)
        {
            //Image<Bgr, Byte> Frame; //current Frame from camera
            //Image<Bgr, Byte> Previous_Frame; //Previiousframe aquired
            Image<Bgr, Byte> Frame = new Image<Bgr, byte>(0, 0); //current Frame from camera
            Image<Bgr, Byte> Previous_Frame = new Image<Bgr, byte>(0, 0); //Previiousframe aquired
            Image<Bgr, Byte> Difference; //Difference between the two frames
            int Threshold = 60; //stores threshold for thread access



            Difference = img2.AbsDiff(img1); //find the absolute difference 
            /*Play with the value 60 to set a threshold for movement*/
            Difference = Difference.ThresholdBinary(new Bgr(Threshold, Threshold, Threshold), new Bgr(255, 255, 255)); //if value > 60 set to 255, 0 otherwise 
            imageBox3.Image = Difference;
            imageBox3.Refresh();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                label1.Text = ofd.FileName;
                imageBox1.Image = new Image<Bgr, byte>(ofd.FileName);
                imageBox1.Refresh();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                label2.Text = ofd.FileName;
                imageBox2.Image = new Image<Bgr, byte>(ofd.FileName);
                imageBox2.Refresh();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Image<Bgr, Byte> Frame = new Image<Bgr,byte>(label1.Text); //current Frame from camera
            Image<Bgr, Byte> Previous_Frame = new Image<Bgr, byte>(label2.Text); //Previiousframe aquired
            Image<Bgr, Byte> Difference; //Difference between the two frames
            int Threshold = 60; //stores threshold for thread access

            //Difference = Previous_Frame.AbsDiff(Frame); //find the absolute difference 
            /*Play with the value 60 to set a threshold for movement*/
            //Difference = Difference.ThresholdBinary(new Bgr(Threshold, Threshold, Threshold), new Bgr(255, 255, 255)); //if value > 60 set to 255, 0 otherwise 
            Difference = Previous_Frame - Frame;
            imageBox3.Image = Difference;
            imageBox3.Refresh();
        }
    }
}
